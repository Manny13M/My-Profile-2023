export class Student
{
    studentNumber! : number;
    fullName! : string;
    username! : string;
    program! : string;
    email! : string;
    dow! : string; //Day of week
    picture!: string;
    
}